package com.pro.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.pro.domain.Book;
import com.pro.domain.Category;
import com.pro.service.BookService;
import com.pro.service.CategoryService;
import com.pro.service.CategoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Yuhua
 * @since 21.7.30 16:28
 */
@Controller
public class BookController {

    @Autowired
    private CategoryService categoryService;
    @Autowired
    private BookService bookService;

    @GetMapping("/")
    public ModelAndView index() {
        ModelAndView mav = new ModelAndView("/index");
        List<Category> categoryList = categoryService.selectAll();
        mav.addObject("categoryList", categoryList);
        return mav;
    }

    @GetMapping("/books")
    @ResponseBody
    public IPage<Book> selectBooks(Long categoryId,String order,Integer nextPage){
        if (nextPage == null) {
            nextPage = 1;
        }
        IPage<Book> pageObject = bookService.pageing(categoryId,order,nextPage, 2);
        return pageObject;
    }
}
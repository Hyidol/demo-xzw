package com.pro.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.pro.domain.Book;

/**
 * @author Yuhua
 * @since 21.8.2 9:16
 */
public interface BookDao extends BaseMapper<Book> {
}
package com.pro.service;

import com.pro.domain.Member;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Yuhua
 * @since 21.8.4 12:45
 */
public interface MemberService {
    Member selectMemberById(Long memberId);
    Member createMember(String username, String password, String nickname);

    Member checkLogin(String username, String password);
}

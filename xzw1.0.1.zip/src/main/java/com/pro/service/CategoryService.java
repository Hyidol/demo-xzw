package com.pro.service;

import com.pro.domain.Category;

import java.util.List;

/**
 * @author Yuhua
 * @since 21.7.30 17:00
 */
public interface CategoryService {
    public List<Category> selectAll();
}
